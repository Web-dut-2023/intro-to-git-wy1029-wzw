var id_top = document.getElementById("head");
id_top.innerHTML = '<object type="text/html" data="./page/head.html" width="100%" height="100%"></object>';
var id_hell = document.getElementById("content");
id_hell.innerHTML = '<object type="text/html" data="./page/hello.html" width="100%" height="100%"></object>';
var imgwid = document.getElementsByTagName("img");
var wid = document.getElementById("photo");
for(var i = 0; i < imgwid.length;i++)
{
    imgwid[i].style["maxWidth"] = wid.offsetWidth+"px";
}

function main_page(){
    var id_ph = document.getElementById("content");
    id_ph.innerHTML = '<object type="text/html" data="./page/mainpage.html" width="100%" height="100%"></object>';
}
function about_me(){
	var con_top = document.getElementById("content");
    con_top.innerHTML = '<object type="text/html" data="./page/about.html" width="100%" height="100%"></object>';
}
function write_bk(){
    var id_wt = document.getElementById("content");
    id_wt.innerHTML = '<object type="text/html" data="./page/write.html" width="100%" height="100%"></object>';
}
function photo(){
    var id_ph = document.getElementById("content");
    id_ph.innerHTML = '<object type="text/html" data="./page/types.html" width="100%" height="100%"></object>';
}
