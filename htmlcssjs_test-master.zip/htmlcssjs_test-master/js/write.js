        
//初始化
function initEditor() {
    openOrCloseEditor("editor", "true");//开启元素编辑
}

function openOrCloseEditor(el, operate) {
    var editor = document.getElementById(el);
    editor.contentEditable = operate;
}
initEditor();

function color(){
    var bt1 = document.getElementById("editor");
    var cor = "#621624|#cc163a|#ed2f6a|#e0c8d1|#cc5595".split("|");
    bt1.style.backgroundColor= cor[i];

}
function blod(){
    var lab = "Bold";
    var btnConfig = "null" ;
    document.execCommand(lab,false,btnConfig);
}
function xie(){
    var lab = "Italic";
    var btnConfig = "null" ;
    document.execCommand(lab,false,btnConfig);
}
function xian(){
    var lab = "Underline";
    var btnConfig = "null" ;
    document.execCommand(lab,false,btnConfig);
}



//  常用函数
const log = (arguments) => console.log(arguments)
const e = (sel) => document.querySelector(sel)

//开始输入并实时插入
var editorEvents = function(editor, preview, md) {
    //  editor 绑定监听事件
    editor.addEventListener('keyup', () => {
        log('开始输入!')
        var val = editor.value
        var text = md.render(val)
        preview.innerHTML = text
    })
}  

//主函数
const __main = function() {
    //  获取到 editor
    var editor = e('#editor')
    // 获取到 preview  
    var preview = e('#preview')
    // 新建一个 remarkable 对象
    var md = new Remarkable()
    editorEvents(editor, preview, md)
}

__main()

