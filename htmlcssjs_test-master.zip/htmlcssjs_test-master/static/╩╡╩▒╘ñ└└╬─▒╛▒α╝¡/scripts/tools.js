//  常用函数
const log = (arguments) => console.log(arguments)
const e = (sel) => document.querySelector(sel)
